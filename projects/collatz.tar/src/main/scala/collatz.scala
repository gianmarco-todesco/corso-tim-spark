import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object Collatz {
  
  def main(args: Array[String]) {
  
    val spark = SparkSession.builder.appName("Square triangular numbers").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    import spark.implicits._

    // definisco la funzione collatz: ritorna la lunghezza del percorso da x a 1
    def collatz(x:Long) : Long = {
      def fun(k:BigDecimal): Long = {
          if(k==1) return 1
          else if(k%2==0) return fun(k/2)+1
          else return fun(3*k+1)+1
      }
      return fun(BigDecimal(x))
    }
    // ne faccio una UDF
    val collatzUdf = udf(collatz(_:Long):Long)

    // considero gli interi da 1 a N
    val N = 500000

    println("==================================================")
    println(" Partito ")
    println(s" N = $N ")
    println("==================================================")
    val startTime = System.nanoTime    

    // creo una tabella con i punti di partenza (x) e le 
    // lunghezze dei relativi percorsi (m)
    val df = spark
      .sparkContext.parallelize(1 to N, 8)
      .toDF("x")
      .withColumn("m", collatzUdf($"x"))
    // il risultato e' il record con il percorso piu' lungo
    val result = df
      .orderBy(desc("m"))
      .first()
            
    val duration = (System.nanoTime - startTime) / 1e9d
    
    println("==================================================")
    println(result)
    printf(" duration = %f\n", duration)
    println("==================================================")    
  }
}
