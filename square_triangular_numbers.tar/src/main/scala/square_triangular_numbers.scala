import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object SquareTriangularNumbers {
  
  def main(args: Array[String]) {
  
    val spark = SparkSession.builder.appName("Square triangular numbers").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    import spark.implicits._

    val limit = BigDecimal("1 000 000 000 000 000".replace(" ",""))
    val qLimit = math.sqrt(limit.toDouble).toLong // Q(qLimit+1) > limit
    val tLimit = qLimit*3/2 // T(tLimit+1) > limit
    
    println("==================================================")
    println(" Partito ")
    println("==================================================")
    val startTime = System.nanoTime    
    
    val t1 = spark.range(1,tLimit+1).toDF("x").withColumn("2T",expr("x*(x+1)"))
    val q1 = spark.range(1,qLimit+1).toDF("y").withColumn("Q",expr("y*y"))
    val t2 = t1.filter($"2T"<limit).repartition(5)
    val q2 = q1.filter($"Q"<limit).repartition(6)
    val df = q2
      .join(t2, expr("2T = 2*Q"))
      .selectExpr("Q as N", "x", "y")
      .orderBy("N")
      
    val results = df.collect()
        
    val duration = (System.nanoTime - startTime) / 1e9d
    
    println("==================================================")
    results.foreach(println)
    printf(" duration = %f\n", duration)
    println("==================================================")
    
  }
}
